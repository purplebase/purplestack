# Secure nsec Storage

Guide to implementing persistent private key storage for nsec-based authentication using Flutter's secure storage.

## ⚠️ Important Security Note

**Only implement persistent private key storage if explicitly requested by the user.** The default and recommended approach is to use the `amber_signer` package with NIP-55 compatible signing apps like Amber.

## When to Use This Pattern

- User specifically requests nsec-based authentication
- Amber app is not available on the target platform
- User wants to import existing nsec keys
- Development/testing scenarios requiring deterministic keys

## Required Dependencies

Add to your `pubspec.yaml`:

```yaml
dependencies:
  flutter_secure_storage: ^9.0.0
```

## Basic Implementation

### Secure Storage Manager

```dart
import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import 'package:models/models.dart';

class SecureSignerManager {
  static const _storage = FlutterSecureStorage(
    aOptions: AndroidOptions(
      encryptedSharedPreferences: true,
    ),
    iOptions: IOSOptions(
      accessibility: KeychainAccessibility.first_unlock_this_device,
    ),
  );
  
  static const _keyPrivateKey = 'nostr_private_key';
  static const _keyPubkey = 'nostr_public_key';

  // Store private key securely
  static Future<void> storePrivateKey(String privateKey) async {
    final pubkey = Utils.derivePublicKey(privateKey);
    
    await Future.wait([
      _storage.write(key: _keyPrivateKey, value: privateKey),
      _storage.write(key: _keyPubkey, value: pubkey),
    ]);
  }

  // Retrieve private key
  static Future<String?> getPrivateKey() async {
    return await _storage.read(key: _keyPrivateKey);
  }
  
  // Retrieve public key
  static Future<String?> getPublicKey() async {
    return await _storage.read(key: _keyPubkey);
  }

  // Clear stored private key
  static Future<void> clearPrivateKey() async {
    await Future.wait([
      _storage.delete(key: _keyPrivateKey),
      _storage.delete(key: _keyPubkey),
    ]);
  }

  // Initialize signer from secure storage
  static Future<Bip340PrivateKeySigner?> initializeFromStorage(WidgetRef ref) async {
    final privateKey = await getPrivateKey();
    if (privateKey != null) {
      return Bip340PrivateKeySigner(privateKey, ref);
    }
    return null;
  }
  
  // Check if keys are stored
  static Future<bool> hasStoredKeys() async {
    final privateKey = await getPrivateKey();
    return privateKey != null && privateKey.isNotEmpty;
  }
}
```

## Authentication Flow Implementation

### Sign-In Screen with nsec Support

```dart
class NsecSignInScreen extends HookConsumerWidget {
  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final nsecController = useTextEditingController();
    final isLoading = useState<bool>(false);
    final errorMessage = useState<String?>(null);
    
    // Check for existing stored keys on mount
    useEffect(() {
      _checkStoredKeys();
      return null;
    }, []);
    
    Future<void> _checkStoredKeys() async {
      if (await SecureSignerManager.hasStoredKeys()) {
        await _autoSignIn();
      }
    }
    
    Future<void> _autoSignIn() async {
      try {
        final signer = await SecureSignerManager.initializeFromStorage(ref);
        if (signer != null) {
          await signer.signIn();
          Navigator.pushReplacement(
            context,
            MaterialPageRoute(builder: (context) => MainScreen()),
          );
        }
      } catch (e) {
        errorMessage.value = 'Auto sign-in failed: $e';
      }
    }
    
    Future<void> _signInWithNsec() async {
      if (nsecController.text.isEmpty) {
        errorMessage.value = 'Please enter your nsec';
        return;
      }
      
      isLoading.value = true;
      errorMessage.value = null;
      
      try {
        final nsec = nsecController.text.trim();
        String privateKey;
        
        // Handle both hex and nsec formats
        if (nsec.startsWith('nsec1')) {
          privateKey = Utils.decodeShareableToString(nsec);
        } else if (nsec.length == 64) {
          privateKey = nsec;
        } else {
          throw Exception('Invalid nsec format');
        }
        
        // Validate the private key
        final pubkey = Utils.derivePublicKey(privateKey);
        if (pubkey.isEmpty) {
          throw Exception('Invalid private key');
        }
        
        // Store securely
        await SecureSignerManager.storePrivateKey(privateKey);
        
        // Create signer and sign in
        final signer = Bip340PrivateKeySigner(privateKey, ref);
        await signer.signIn();
        
        // Navigate to main screen
        Navigator.pushReplacement(
          context,
          MaterialPageRoute(builder: (context) => MainScreen()),
        );
        
      } catch (e) {
        errorMessage.value = 'Sign-in failed: $e';
      } finally {
        isLoading.value = false;
      }
    }
    
    return Scaffold(
      appBar: AppBar(title: Text('Sign In with nsec')),
      body: Padding(
        padding: EdgeInsets.all(16),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            TextField(
              controller: nsecController,
              decoration: InputDecoration(
                labelText: 'Private Key (nsec or hex)',
                hintText: 'nsec1... or 64-character hex',
                border: OutlineInputBorder(),
                errorText: errorMessage.value,
              ),
              obscureText: true,
              maxLines: 1,
            ),
            
            SizedBox(height: 24),
            
            FilledButton(
              onPressed: isLoading.value ? null : _signInWithNsec,
              child: isLoading.value
                ? Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      SizedBox(
                        width: 16,
                        height: 16,
                        child: CircularProgressIndicator(strokeWidth: 2),
                      ),
                      SizedBox(width: 8),
                      Text('Signing in...'),
                    ],
                  )
                : Text('Sign In'),
            ),
            
            SizedBox(height: 16),
            
            TextButton(
              onPressed: () => _showSecurityWarning(context),
              child: Text('Security Information'),
            ),
          ],
        ),
      ),
    );
  }
  
  void _showSecurityWarning(BuildContext context) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: Text('Security Warning'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('Storing private keys on device:'),
            SizedBox(height: 8),
            Text('• Keys are encrypted using platform keychain'),
            Text('• Device compromise may expose keys'),
            Text('• Consider using Amber signer for better security'),
            SizedBox(height: 16),
            Text('Only proceed if you understand the risks.'),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: Text('I Understand'),
          ),
        ],
      ),
    );
  }
}
```

### Key Generation and Import

```dart
class KeyManagementScreen extends HookConsumerWidget {
  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final generatedNsec = useState<String?>(null);
    final importController = useTextEditingController();
    
    return Scaffold(
      appBar: AppBar(title: Text('Key Management')),
      body: Padding(
        padding: EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            // Generate new key section
            Card(
              child: Padding(
                padding: EdgeInsets.all(16),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text('Generate New Key', style: Theme.of(context).textTheme.titleMedium),
                    SizedBox(height: 8),
                    Text('Create a new private key for your Nostr identity.'),
                    SizedBox(height: 16),
                    
                    if (generatedNsec.value != null) ...[
                      Container(
                        padding: EdgeInsets.all(12),
                        decoration: BoxDecoration(
                          border: Border.all(color: Colors.grey),
                          borderRadius: BorderRadius.circular(8),
                        ),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text('Your new nsec:', style: TextStyle(fontWeight: FontWeight.bold)),
                            SizedBox(height: 4),
                            SelectableText(
                              generatedNsec.value!,
                              style: TextStyle(fontFamily: 'monospace', fontSize: 12),
                            ),
                            SizedBox(height: 8),
                            Text(
                              '⚠️ Save this securely! It cannot be recovered if lost.',
                              style: TextStyle(color: Colors.orange, fontWeight: FontWeight.bold),
                            ),
                          ],
                        ),
                      ),
                      SizedBox(height: 16),
                    ],
                    
                    Row(
                      children: [
                        ElevatedButton(
                          onPressed: () => _generateNewKey(generatedNsec),
                          child: Text('Generate Key'),
                        ),
                        SizedBox(width: 16),
                        if (generatedNsec.value != null)
                          FilledButton(
                            onPressed: () => _useGeneratedKey(ref, generatedNsec.value!, context),
                            child: Text('Use This Key'),
                          ),
                      ],
                    ),
                  ],
                ),
              ),
            ),
            
            SizedBox(height: 16),
            
            // Import existing key section
            Card(
              child: Padding(
                padding: EdgeInsets.all(16),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text('Import Existing Key', style: Theme.of(context).textTheme.titleMedium),
                    SizedBox(height: 8),
                    Text('Import your existing nsec private key.'),
                    SizedBox(height: 16),
                    
                    TextField(
                      controller: importController,
                      decoration: InputDecoration(
                        labelText: 'Private Key (nsec or hex)',
                        hintText: 'nsec1... or 64-character hex',
                        border: OutlineInputBorder(),
                      ),
                      obscureText: true,
                    ),
                    
                    SizedBox(height: 16),
                    
                    FilledButton(
                      onPressed: () => _importKey(ref, importController.text, context),
                      child: Text('Import Key'),
                    ),
                  ],
                ),
              ),
            ),
            
            SizedBox(height: 32),
            
            // Security warning
            Container(
              padding: EdgeInsets.all(16),
              decoration: BoxDecoration(
                color: Colors.orange.withOpacity(0.1),
                border: Border.all(color: Colors.orange),
                borderRadius: BorderRadius.circular(8),
              ),
              child: Column(
                children: [
                  Icon(Icons.warning, color: Colors.orange),
                  SizedBox(height: 8),
                  Text(
                    'Private keys are stored encrypted on your device. For maximum security, consider using external signers like Amber.',
                    textAlign: TextAlign.center,
                    style: TextStyle(color: Colors.orange[800]),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
  
  void _generateNewKey(ValueNotifier<String?> generatedNsec) {
    final privateKey = Utils.generateRandomHex64();
    final nsec = Utils.encodeShareableFromString(privateKey, type: 'nsec');
    generatedNsec.value = nsec;
  }
  
  Future<void> _useGeneratedKey(WidgetRef ref, String nsec, BuildContext context) async {
    try {
      final privateKey = Utils.decodeShareableToString(nsec);
      await SecureSignerManager.storePrivateKey(privateKey);
      
      final signer = Bip340PrivateKeySigner(privateKey, ref);
      await signer.signIn();
      
      Navigator.pushAndRemoveUntil(
        context,
        MaterialPageRoute(builder: (context) => MainScreen()),
        (route) => false,
      );
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Failed to use key: $e')),
      );
    }
  }
  
  Future<void> _importKey(WidgetRef ref, String input, BuildContext context) async {
    try {
      String privateKey;
      
      if (input.startsWith('nsec1')) {
        privateKey = Utils.decodeShareableToString(input);
      } else if (input.length == 64) {
        privateKey = input;
      } else {
        throw Exception('Invalid key format');
      }
      
      // Validate the key
      Utils.derivePublicKey(privateKey);
      
      await SecureSignerManager.storePrivateKey(privateKey);
      
      final signer = Bip340PrivateKeySigner(privateKey, ref);
      await signer.signIn();
      
      Navigator.pushAndRemoveUntil(
        context,
        MaterialPageRoute(builder: (context) => MainScreen()),
        (route) => false,
      );
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Failed to import key: $e')),
      );
    }
  }
}
```

## Security Considerations

### Storage Configuration

```dart
class SecureStorageConfig {
  static const FlutterSecureStorage storage = FlutterSecureStorage(
    aOptions: AndroidOptions(
      encryptedSharedPreferences: true,
      // Use hardware security if available
      useHardwareKeystore: true,
    ),
    iOptions: IOSOptions(
      // Require device unlock to access
      accessibility: KeychainAccessibility.when_unlocked_this_device_only,
      // Require biometric or passcode
      synchronizable: false,
    ),
    lOptions: LinuxOptions(
      useSessionKeyring: true,
    ),
    wOptions: WindowsOptions(
      useHardwareEncryption: true,
    ),
  );
}
```

### Key Rotation

```dart
class KeyRotationManager {
  static Future<void> rotateKeys(WidgetRef ref) async {
    // Generate new key pair
    final newPrivateKey = Utils.generateRandomHex64();
    final newPubkey = Utils.derivePublicKey(newPrivateKey);
    
    // Create key rotation event
    final rotationEvent = PartialKeyRotation(
      newPublicKey: newPubkey,
      reason: 'Security rotation',
    );
    
    // Sign with old key
    final oldSigner = ref.read(Signer.activeSignerProvider);
    final signedRotation = await rotationEvent.signWith(oldSigner);
    
    // Publish rotation event
    await ref.storage.publish({signedRotation});
    
    // Store new key
    await SecureSignerManager.storePrivateKey(newPrivateKey);
    
    // Switch to new signer
    final newSigner = Bip340PrivateKeySigner(newPrivateKey, ref);
    await newSigner.signIn();
  }
}
```

## Best Practices

### Security Guidelines

1. **Always warn users** about the security implications
2. **Use hardware security** when available (Android Keystore, iOS Secure Enclave)
3. **Implement key rotation** for long-term security
4. **Clear keys on app uninstall** or user logout
5. **Consider biometric authentication** for key access

### Error Handling

```dart
class SecureKeyError implements Exception {
  final String message;
  final String code;
  
  const SecureKeyError(this.message, this.code);
  
  @override
  String toString() => 'SecureKeyError: $message (code: $code)';
}

Future<String?> safeGetPrivateKey() async {
  try {
    return await SecureSignerManager.getPrivateKey();
  } on PlatformException catch (e) {
    if (e.code == 'UserCancel') {
      throw SecureKeyError('User cancelled authentication', 'AUTH_CANCELLED');
    } else if (e.code == 'NotAvailable') {
      throw SecureKeyError('Secure storage not available', 'NOT_AVAILABLE');
    } else {
      throw SecureKeyError('Failed to access secure storage: ${e.message}', 'PLATFORM_ERROR');
    }
  } catch (e) {
    throw SecureKeyError('Unexpected error accessing keys: $e', 'UNKNOWN');
  }
}
```

### Migration from Amber

```dart
class SignerMigration {
  static Future<void> migrateFromAmber(WidgetRef ref) async {
    // Show migration dialog explaining the change
    final confirmed = await showMigrationDialog();
    if (!confirmed) return;
    
    // Export key from Amber (if supported)
    // This would require Amber API support for key export
    
    // Import into secure storage
    // await SecureSignerManager.storePrivateKey(exportedKey);
    
    // Switch signer
    // final newSigner = await SecureSignerManager.initializeFromStorage(ref);
    // await newSigner?.signIn();
  }
}
```

Remember: This approach should only be used when Amber signer is not available or specifically requested by the user. The security implications should always be clearly explained to users. 