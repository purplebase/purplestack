# Engagement Interactions

Complete guide to implementing social engagement features (likes, reposts, zaps, comments) for Nostr notes using the EngagementRow widget.

## Overview

The `EngagementRow` widget provides a clean, Material 3 interface for displaying and interacting with social engagement metrics on Nostr notes.

## Basic Implementation

### Simple Display-Only Engagement

```dart
import 'package:purplestack/widgets/common/engagement_row.dart';

class NoteCard extends ConsumerWidget {
  final Note note;
  
  const NoteCard({required this.note, super.key});
  
  @override
  Widget build(BuildContext context, WidgetRef ref) {
    return Card(
      child: Padding(
        padding: EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Note content
            ParsedContentWidget(content: note.content),
            
            SizedBox(height: 12),
            
            // Engagement metrics
            EngagementRow(
              likesCount: note.reactions.length,
              repostsCount: note.reposts.length,
              zapsCount: note.zaps.length,
              zapsSatAmount: note.zaps.toList().fold(0, (sum, zap) => sum + zap.amount),
              commentsCount: note.replies.length,
            ),
          ],
        ),
      ),
    );
  }
}
```

### Required Query Relationships

For engagement features to work, ensure your note queries include relationships:

```dart
class NoteFeed extends ConsumerWidget {
  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final notesState = ref.watch(
      query<Note>(
        limit: 50,
        and: (note) => {
          note.author,      // For author info
          note.reactions,   // For likes count and state
          note.reposts,     // For reposts count and state
          note.zaps,        // For zaps count and sat amounts
          note.replies,     // For comments count (optional)
        },
      ),
    );
    
    return switch (notesState) {
      StorageLoading() => FeedSkeleton(),
      StorageError(:final error) => ErrorWidget(error),
      StorageData(:final models) => ListView.builder(
        itemCount: models.length,
        itemBuilder: (context, index) => InteractiveNoteCard(note: models[index]),
      ),
    };
  }
}
```

## Interactive Engagement Implementation

### Complete Interactive Note Card

```dart
class InteractiveNoteCard extends HookConsumerWidget {
  final Note note;
  
  const InteractiveNoteCard({required this.note, super.key});
  
  @override
  Widget build(BuildContext context, WidgetRef ref) {
    // Get current user's pubkey for interaction state
    final activePubkey = ref.watch(Signer.activePubkeyProvider);
    
    // Calculate user interaction state
    final userHasLiked = activePubkey != null &&
        note.reactions.toList().any((r) => r.author.value?.pubkey == activePubkey);
    final userHasReposted = activePubkey != null &&
        note.reposts.toList().any((r) => r.author.value?.pubkey == activePubkey);
    final userHasZapped = activePubkey != null &&
        note.zaps.toList().any((z) => z.author.value?.pubkey == activePubkey);
    
    return Card(
      child: Padding(
        padding: EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Author info
            Row(
              children: [
                ProfileAvatar(profile: note.author.value, radius: 20),
                SizedBox(width: 12),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        note.author.value?.displayName ?? 'Anonymous',
                        style: Theme.of(context).textTheme.titleSmall,
                      ),
                      Text(
                        TimeUtils.formatTimestamp(note.createdAt),
                        style: Theme.of(context).textTheme.bodySmall,
                      ),
                    ],
                  ),
                ),
              ],
            ),
            
            SizedBox(height: 12),
            
            // Note content
            ParsedContentWidget(
              content: note.content,
              onProfileTap: (pubkey) => context.push('/profile/$pubkey'),
              onHashtagTap: (hashtag) => context.push('/hashtag/$hashtag'),
            ),
            
            SizedBox(height: 16),
            
            // Interactive engagement row
            EngagementRow(
              likesCount: note.reactions.length,
              repostsCount: note.reposts.length,
              zapsCount: note.zaps.length,
              zapsSatAmount: note.zaps.toList().fold(0, (sum, zap) => sum + zap.amount),
              commentsCount: note.replies.length,
              
              // User interaction state
              isLiked: userHasLiked,
              isReposted: userHasReposted,
              isZapped: userHasZapped,
              
              // Interaction callbacks
              onLike: activePubkey != null ? () => _handleLike(ref, note) : null,
              onRepost: activePubkey != null ? () => _handleRepost(ref, note) : null,
              onZap: activePubkey != null ? () => _handleZap(context, ref, note) : null,
              onComment: () => _handleComment(context, note),
            ),
          ],
        ),
      ),
    );
  }
  
  Future<void> _handleLike(WidgetRef ref, Note note) async {
    try {
      final signer = ref.read(Signer.activeSignerProvider);
      
      final reaction = PartialReaction(
        reactedOn: note,
        emojiTag: ('+', null), // Standard like reaction
      );
      
      final signedReaction = await reaction.signWith(signer);
      
      // Save locally and publish to relays
      await ref.storage.save({signedReaction});
      await ref.storage.publish({signedReaction});
      
    } catch (e) {
      debugPrint('Failed to like note: $e');
    }
  }
  
  Future<void> _handleRepost(WidgetRef ref, Note note) async {
    try {
      final signer = ref.read(Signer.activeSignerProvider);
      
      final repost = PartialRepost(originalEvent: note);
      
      final signedRepost = await repost.signWith(signer);
      
      // Save locally and publish to relays
      await ref.storage.save({signedRepost});
      await ref.storage.publish({signedRepost});
      
    } catch (e) {
      debugPrint('Failed to repost note: $e');
    }
  }
  
  Future<void> _handleZap(BuildContext context, WidgetRef ref, Note note) async {
    // Show zap amount selection dialog
    final zapAmount = await showZapDialog(context);
    
    if (zapAmount != null && zapAmount > 0) {
      try {
        await _performZap(ref, note, zapAmount);
      } catch (e) {
        if (context.mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(content: Text('Failed to send zap: $e')),
          );
        }
      }
    }
  }
  
  void _handleComment(BuildContext context, Note note) {
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) => ReplyComposerScreen(parentNote: note),
      ),
    );
  }
  
  Future<void> _performZap(WidgetRef ref, Note note, int satAmount) async {
    // Implementation depends on your zap/NWC setup
    // See zaps-with-nwc.md recipe for complete implementation
    final signer = ref.read(Signer.activeSignerProvider);
    
    // Create zap request
    final zapRequest = PartialZapRequest(
      zapAmount: satAmount,
      zapTarget: note,
    );
    
    final signedZapRequest = await zapRequest.signWith(signer);
    
    // Send to Lightning wallet/NWC
    // Implementation details in zaps-with-nwc.md
  }
}
```

## Async UI Patterns for Engagement

### Using AsyncButtonBuilder for Smooth Interactions

```dart
class AsyncEngagementRow extends HookConsumerWidget {
  final Note note;
  
  const AsyncEngagementRow({required this.note, super.key});
  
  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final activePubkey = ref.watch(Signer.activePubkeyProvider);
    
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceAround,
      children: [
        // Like button with async state
        AsyncButtonBuilder(
          child: Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              Icon(Icons.favorite_border, size: 20),
              SizedBox(width: 4),
              Text('${note.reactions.length}'),
            ],
          ),
          onPressed: activePubkey != null ? () => _handleLike(ref, note) : null,
          builder: (context, child, callback, buttonState) {
            return InkWell(
              onTap: buttonState.maybeWhen(
                loading: () => null,
                orElse: () => callback,
              ),
              borderRadius: BorderRadius.circular(8),
              child: Padding(
                padding: EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                child: buttonState.maybeWhen(
                  loading: () => Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      SizedBox(
                        width: 16,
                        height: 16,
                        child: CircularProgressIndicator(strokeWidth: 2),
                      ),
                      SizedBox(width: 4),
                      Text('${note.reactions.length}'),
                    ],
                  ),
                  orElse: () => child,
                ),
              ),
            );
          },
        ),
        
        // Repost button
        AsyncButtonBuilder(
          child: Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              Icon(Icons.repeat, size: 20),
              SizedBox(width: 4),
              Text('${note.reposts.length}'),
            ],
          ),
          onPressed: activePubkey != null ? () => _handleRepost(ref, note) : null,
          builder: (context, child, callback, buttonState) {
            return InkWell(
              onTap: buttonState.maybeWhen(
                loading: () => null,
                orElse: () => callback,
              ),
              borderRadius: BorderRadius.circular(8),
              child: Padding(
                padding: EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                child: buttonState.maybeWhen(
                  loading: () => Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      SizedBox(
                        width: 16,
                        height: 16,
                        child: CircularProgressIndicator(strokeWidth: 2),
                      ),
                      SizedBox(width: 4),
                      Text('${note.reposts.length}'),
                    ],
                  ),
                  orElse: () => child,
                ),
              ),
            );
          },
        ),
        
        // Zap button
        InkWell(
          onTap: () => _handleZap(context, ref, note),
          borderRadius: BorderRadius.circular(8),
          child: Padding(
            padding: EdgeInsets.symmetric(horizontal: 12, vertical: 8),
            child: Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                Icon(Icons.bolt, size: 20),
                SizedBox(width: 4),
                Text(_formatZapDisplay(note.zaps.toList())),
              ],
            ),
          ),
        ),
        
        // Comment button
        InkWell(
          onTap: () => _handleComment(context, note),
          borderRadius: BorderRadius.circular(8),
          child: Padding(
            padding: EdgeInsets.symmetric(horizontal: 12, vertical: 8),
            child: Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                Icon(Icons.comment_outlined, size: 20),
                SizedBox(width: 4),
                Text('${note.replies.length}'),
              ],
            ),
          ),
        ),
      ],
    );
  }
  
  String _formatZapDisplay(List<Zap> zaps) {
    if (zaps.isEmpty) return '0';
    
    final totalSats = zaps.fold(0, (sum, zap) => sum + zap.amount);
    if (totalSats > 0) {
      return _formatSatAmount(totalSats);
    }
    
    return '${zaps.length}';
  }
  
  String _formatSatAmount(int sats) {
    if (sats >= 1000000) return '${(sats / 1000000).toStringAsFixed(1)}M';
    if (sats >= 1000) return '${(sats / 1000).toStringAsFixed(1)}K';
    return '$sats';
  }
  
  // ... other methods remain the same
}
```

## Advanced Patterns

### Zap Amount Selection Dialog

```dart
Future<int?> showZapDialog(BuildContext context) async {
  return await showDialog<int>(
    context: context,
    builder: (context) => ZapDialog(),
  );
}

class ZapDialog extends StatefulWidget {
  @override
  State<ZapDialog> createState() => _ZapDialogState();
}

class _ZapDialogState extends State<ZapDialog> {
  int selectedAmount = 21;
  final customController = TextEditingController();
  
  final quickAmounts = [21, 100, 500, 1000, 5000];
  
  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      title: Text('Send Zap ⚡'),
      content: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Text('Select amount in sats:'),
          SizedBox(height: 16),
          
          // Quick amount buttons
          Wrap(
            spacing: 8,
            children: quickAmounts.map((amount) {
              final isSelected = selectedAmount == amount;
              return FilterChip(
                label: Text('$amount'),
                selected: isSelected,
                onSelected: (selected) {
                  setState(() => selectedAmount = amount);
                  customController.clear();
                },
              );
            }).toList(),
          ),
          
          SizedBox(height: 16),
          
          // Custom amount input
          TextField(
            controller: customController,
            decoration: InputDecoration(
              labelText: 'Custom amount',
              border: OutlineInputBorder(),
            ),
            keyboardType: TextInputType.number,
            onChanged: (value) {
              final customAmount = int.tryParse(value);
              if (customAmount != null) {
                setState(() => selectedAmount = customAmount);
              }
            },
          ),
        ],
      ),
      actions: [
        TextButton(
          onPressed: () => Navigator.pop(context),
          child: Text('Cancel'),
        ),
        FilledButton(
          onPressed: selectedAmount > 0 
              ? () => Navigator.pop(context, selectedAmount)
              : null,
          child: Text('Zap $selectedAmount sats'),
        ),
      ],
    );
  }
}
```

### Reply Composer Screen

```dart
class ReplyComposerScreen extends HookConsumerWidget {
  final Note parentNote;
  
  const ReplyComposerScreen({required this.parentNote, super.key});
  
  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final textController = useTextEditingController();
    
    return Scaffold(
      appBar: AppBar(
        title: Text('Reply'),
        actions: [
          AsyncButtonBuilder(
            child: Text('Reply'),
            onPressed: () => _publishReply(ref, textController.text),
            builder: (context, child, callback, buttonState) {
              return TextButton(
                onPressed: buttonState.maybeWhen(
                  loading: () => null,
                  orElse: () => textController.text.isEmpty ? null : callback,
                ),
                child: buttonState.maybeWhen(
                  loading: () => SizedBox(
                    width: 16,
                    height: 16,
                    child: CircularProgressIndicator(strokeWidth: 2),
                  ),
                  orElse: () => child,
                ),
              );
            },
          ),
        ],
      ),
      body: Column(
        children: [
          // Show parent note for context
          Container(
            padding: EdgeInsets.all(16),
            decoration: BoxDecoration(
              color: Theme.of(context).colorScheme.surface,
              border: Border(
                bottom: BorderSide(
                  color: Theme.of(context).dividerColor,
                ),
              ),
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  'Replying to ${parentNote.author.value?.displayName ?? 'Anonymous'}',
                  style: Theme.of(context).textTheme.bodySmall,
                ),
                SizedBox(height: 8),
                Text(
                  parentNote.content,
                  style: Theme.of(context).textTheme.bodyMedium,
                  maxLines: 3,
                  overflow: TextOverflow.ellipsis,
                ),
              ],
            ),
          ),
          
          // Reply input
          Expanded(
            child: Padding(
              padding: EdgeInsets.all(16),
              child: TextField(
                controller: textController,
                decoration: InputDecoration(
                  hintText: 'Write your reply...',
                  border: InputBorder.none,
                ),
                maxLines: null,
                expands: true,
                textAlignVertical: TextAlignVertical.top,
                autofocus: true,
              ),
            ),
          ),
        ],
      ),
    );
  }
  
  Future<void> _publishReply(WidgetRef ref, String content) async {
    try {
      final signer = ref.read(Signer.activeSignerProvider);
      
      final reply = PartialNote(content)
        ..replyTo = parentNote; // Sets appropriate e and p tags
      
      final signedReply = await reply.signWith(signer);
      
      // Save locally and publish to relays
      await ref.storage.save({signedReply});
      await ref.storage.publish({signedReply});
      
      Navigator.pop(context);
      
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Failed to publish reply: $e')),
      );
    }
  }
}
```

## Best Practices

### Performance Optimization

- **Load relationships efficiently** - use `and` operator in queries
- **Cache user interaction state** - avoid recalculating likes/reposts  
- **Debounce rapid interactions** - prevent double-taps
- **Show optimistic updates** - update UI immediately, sync later

### User Experience

- **Immediate visual feedback** - change button appearance instantly
- **Clear loading states** - show progress for async operations
- **Graceful error handling** - don't crash on network failures
- **Offline capability** - queue actions when network unavailable

### Accessibility

```dart
// Add semantic labels for screen readers
Semantics(
  label: 'Like button, ${note.reactions.length} likes',
  button: true,
  child: InkWell(
    onTap: () => _handleLike(ref, note),
    child: Row(
      children: [
        Icon(Icons.favorite),
        Text('${note.reactions.length}'),
      ],
    ),
  ),
)
```

### Testing Engagement Features

```dart
// Widget test example
testWidgets('shows engagement counts correctly', (tester) async {
  final mockNote = Note.fromMap({
    // Mock note data with reactions, reposts, etc.
  });
  
  await tester.pumpWidget(
    MaterialApp(
      home: Scaffold(
        body: EngagementRow(
          likesCount: 5,
          repostsCount: 2,
          zapsCount: 10,
          zapsSatAmount: 2100,
        ),
      ),
    ),
  );
  
  expect(find.text('5'), findsOneWidget); // Likes count
  expect(find.text('2'), findsOneWidget); // Reposts count
  expect(find.text('2.1K'), findsOneWidget); // Formatted zap amount
});
```

Remember: Social engagement is core to Nostr's value proposition. Make these interactions smooth, responsive, and delightful! 