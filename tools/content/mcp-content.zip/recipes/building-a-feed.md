# Building a Feed

Create a reactive feed that updates in real-time.

## Home Feed with Relationships

```dart
import 'package:purplestack/widgets/common/profile_avatar.dart';
import 'package:purplestack/widgets/common/note_parser.dart';
import 'package:purplestack/widgets/common/engagement_row.dart';
import 'package:purplestack/widgets/common/time_utils.dart';

class HomeFeed extends ConsumerWidget {
  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final activeProfile = ref.watch(Signer.activeProfileProvider(LocalSource()));
    
    if (activeProfile == null) {
      return Center(child: Text('Please sign in'));
    }
    
    // Get following pubkeys from contact list
    final following = activeProfile.contactList.value?.followingPubkeys ?? {};
    
    final feedState = ref.watch(
      query<Note>(
        authors: following,
        limit: 50,
        and: (note) => {
          note.author,           // Include author profile
          note.reactions,        // Include reactions
          note.zaps,            // Include zaps
          note.root,            // Include root note for replies
          note.replies,         // Include direct replies
        },
      ),
    );
    
    return switch (feedState) {
      StorageLoading() => Center(child: CircularProgressIndicator()),
      StorageError() => Center(child: Text('Error loading feed')),
      StorageData() => ListView.builder(
        itemCount: feedState.models.length,
        itemBuilder: (context, index) {
          final note = feedState.models[index];
          return FeedItemCard(note: note);
        },
      ),
    };
  }
}

class FeedItemCard extends StatelessWidget {
  final Note note;
  
  const FeedItemCard({required this.note, super.key});
  
  @override
  Widget build(BuildContext context) {
    return Card(
      child: Padding(
        padding: EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Author info
            Row(
              children: [
                ProfileAvatar(profile: note.author.value, radius: 20),
                SizedBox(width: 8),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        note.author.value?.displayName ?? 'Anonymous',
                        style: Theme.of(context).textTheme.titleSmall,
                      ),
                      Text(
                        TimeUtils.formatTimestamp(note.createdAt),
                        style: Theme.of(context).textTheme.bodySmall,
                      ),
                    ],
                  ),
                ),
              ],
            ),
            SizedBox(height: 12),
            
            // Note content - use ParsedContentWidget for proper parsing
            ParsedContentWidget(
              content: note.content,
              onProfileTap: (pubkey) => context.push('/profile/$pubkey'),
              onHashtagTap: (hashtag) => context.push('/hashtag/$hashtag'),
            ),
            SizedBox(height: 12),
            
            // Reply indicator
            if (note.root.value != null) ...[
              Row(
                children: [
                  Icon(Icons.reply, size: 16, color: Colors.grey[600]),
                  SizedBox(width: 4),
                  Text(
                    'Reply to ${note.root.value!.author.value?.displayName ?? 'Unknown'}',
                    style: Theme.of(context).textTheme.bodySmall?.copyWith(
                      color: Colors.grey[600],
                    ),
                  ),
                ],
              ),
              SizedBox(height: 8),
            ],
            
            // Engagement metrics using the common widget
            EngagementRow(
              likesCount: note.reactions.length,
              repostsCount: note.reposts.length,
              zapsCount: note.zaps.length,
              zapsSatAmount: note.zaps.toList().fold(0, (sum, zap) => sum + zap.amount),
              commentsCount: note.replies.length,
              
              // Add interaction callbacks for full functionality
              // onLike: () => _handleLike(context, note),
              // onRepost: () => _handleRepost(context, note), 
              // onZap: () => _handleZap(context, note),
              // onComment: () => _handleComment(context, note),
            ),
          ],
        ),
      ),
    );
  }
}
```

## Real-time Updates

```dart
// The feed automatically updates when new notes arrive
// thanks to the reactive query system

// You can also manually trigger updates
final storage = ref.read(storageNotifierProvider.notifier);

// Save a new note and it will appear in the feed
final newNote = await PartialNote('Hello, world!').signWith(signer);
await storage.save({newNote});
``` 