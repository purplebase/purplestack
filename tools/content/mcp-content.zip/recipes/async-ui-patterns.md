# Async UI Patterns

Complete guide to implementing responsive async operations in Flutter using `async_button_builder` for better user experience.

## Overview

Use `async_button_builder` for any operation that takes time and could fail, providing immediate feedback and preventing multiple simultaneous operations.

## When to Use

- **Authentication operations**: Sign in, sign out, account switching
- **Network operations**: Posting notes, liking, reposting, zapping
- **File operations**: Uploading media, processing files  
- **Any operation that takes >500ms**: Long-running computations, API calls

## Basic Patterns

### Icon Button with Loading State

```dart
import 'package:async_button_builder/async_button_builder.dart';

class LikeButton extends ConsumerWidget {
  final Note note;
  
  const LikeButton({required this.note, super.key});
  
  @override
  Widget build(BuildContext context, WidgetRef ref) {
    return AsyncButtonBuilder(
      child: const Icon(Icons.favorite),
      onPressed: () async {
        await _performLike(ref);
      },
      builder: (context, child, callback, buttonState) {
        return IconButton(
          icon: buttonState.maybeWhen(
            loading: () => const SizedBox(
              width: 20,
              height: 20,
              child: CircularProgressIndicator(strokeWidth: 2),
            ),
            orElse: () => child,
          ),
          onPressed: buttonState.maybeWhen(
            loading: () => null, // Disable during loading
            orElse: () => callback,
          ),
        );
      },
      onError: () {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Like failed')),
        );
      },
    );
  }
  
  Future<void> _performLike(WidgetRef ref) async {
    final signer = ref.read(Signer.activeSignerProvider);
    final reaction = PartialReaction(
      reactedOn: note,
      emojiTag: ('+', null),
    );
    final signedReaction = await reaction.signWith(signer);
    await ref.storage.publish({signedReaction});
  }
}
```

### Filled Button with Text Loading

```dart
class SignInButton extends ConsumerWidget {
  @override
  Widget build(BuildContext context, WidgetRef ref) {
    return AsyncButtonBuilder(
      child: Text('Sign In with Amber'),
      onPressed: () async {
        await ref.read(amberSignerProvider).signIn();
      },
      builder: (context, child, callback, buttonState) {
        return FilledButton(
          onPressed: buttonState.maybeWhen(
            loading: () => null,
            orElse: () => callback,
          ),
          child: buttonState.maybeWhen(
            loading: () => Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                SizedBox(
                  width: 20,
                  height: 20,
                  child: CircularProgressIndicator(
                    strokeWidth: 2,
                    color: Colors.white,
                  ),
                ),
                SizedBox(width: 8),
                Text('Signing in...'),
              ],
            ),
            orElse: () => child,
          ),
        );
      },
      onError: () {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('Sign-in failed. Please install Amber app.'),
            action: SnackBarAction(
              label: 'Install',
              onPressed: () => launchUrl(
                Uri.parse('https://github.com/greenart7c3/Amber'),
              ),
            ),
          ),
        );
      },
    );
  }
}
```

## Advanced Integration Patterns

### Custom Widget with Async Operations

```dart
class EngagementRowWithAsync extends HookConsumerWidget {
  final Note note;
  
  const EngagementRowWithAsync({required this.note, super.key});
  
  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final isLiking = useState<bool>(false);
    final isReposting = useState<bool>(false);
    final isZapping = useState<bool>(false);
    
    return EngagementRow(
      likesCount: note.reactions.length,
      repostsCount: note.reposts.length,
      zapsCount: note.zaps.length,
      zapsSatAmount: note.zaps.toList().fold(0, (sum, zap) => sum + zap.amount),
      
      // Loading states
      isLiking: isLiking.value,
      isReposting: isReposting.value,
      isZapping: isZapping.value,
      
      // Async callbacks
      onLike: () => _handleAsync(
        isLiking,
        () => _performLike(ref),
        context,
        'Like failed',
      ),
      
      onRepost: () => _handleAsync(
        isReposting,
        () => _performRepost(ref),
        context,
        'Repost failed',
      ),
      
      onZap: () => _handleAsync(
        isZapping,
        () => _performZap(ref, context),
        context,
        'Zap failed',
      ),
    );
  }
  
  Future<void> _handleAsync(
    ValueNotifier<bool> loadingState,
    Future<void> Function() operation,
    BuildContext context,
    String errorMessage,
  ) async {
    if (loadingState.value) return;
    
    loadingState.value = true;
    try {
      await operation();
    } catch (e) {
      if (context.mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('$errorMessage: $e')),
        );
      }
    } finally {
      loadingState.value = false;
    }
  }
  
  Future<void> _performLike(WidgetRef ref) async {
    final signer = ref.read(Signer.activeSignerProvider);
    final reaction = PartialReaction(
      reactedOn: note,
      emojiTag: ('+', null),
    );
    final signedReaction = await reaction.signWith(signer);
    await ref.storage.save({signedReaction});
    await ref.storage.publish({signedReaction});
  }
  
  Future<void> _performRepost(WidgetRef ref) async {
    final signer = ref.read(Signer.activeSignerProvider);
    final repost = PartialRepost(originalEvent: note);
    final signedRepost = await repost.signWith(signer);
    await ref.storage.save({signedRepost});
    await ref.storage.publish({signedRepost});
  }
  
  Future<void> _performZap(WidgetRef ref, BuildContext context) async {
    // Implementation for zap - might show dialog first
    final zapAmount = await showZapDialog(context);
    if (zapAmount != null) {
      // Perform zap operation
    }
  }
}
```

### Form Submission with Progress

```dart
class NoteComposerForm extends HookConsumerWidget {
  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final textController = useTextEditingController();
    final attachments = useState<List<String>>([]);
    
    return Column(
      children: [
        Expanded(
          child: TextField(
            controller: textController,
            decoration: InputDecoration(
              hintText: 'What\'s happening?',
              border: InputBorder.none,
            ),
            maxLines: null,
            expands: true,
          ),
        ),
        
        // Attachment preview
        if (attachments.value.isNotEmpty)
          AttachmentPreview(urls: attachments.value),
        
        // Bottom toolbar
        Row(
          children: [
            // Media attach button
            AsyncButtonBuilder(
              child: Icon(Icons.photo),
              onPressed: () async {
                final urls = await _uploadMedia();
                if (urls.isNotEmpty) {
                  attachments.value = [...attachments.value, ...urls];
                }
              },
              builder: (context, child, callback, buttonState) {
                return IconButton(
                  icon: buttonState.maybeWhen(
                    loading: () => SizedBox(
                      width: 20,
                      height: 20,
                      child: CircularProgressIndicator(strokeWidth: 2),
                    ),
                    orElse: () => child,
                  ),
                  onPressed: buttonState.maybeWhen(
                    loading: () => null,
                    orElse: () => callback,
                  ),
                );
              },
            ),
            
            Spacer(),
            
            // Character count
            Text('${textController.text.length}/280'),
            
            SizedBox(width: 16),
            
            // Publish button
            AsyncButtonBuilder(
              child: Text('Publish'),
              onPressed: () async {
                await _publishNote(ref, textController.text, attachments.value);
                Navigator.pop(context);
              },
              builder: (context, child, callback, buttonState) {
                return FilledButton(
                  onPressed: buttonState.maybeWhen(
                    loading: () => null,
                    orElse: () => textController.text.isEmpty ? null : callback,
                  ),
                  child: buttonState.maybeWhen(
                    loading: () => Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        SizedBox(
                          width: 16,
                          height: 16,
                          child: CircularProgressIndicator(
                            strokeWidth: 2,
                            color: Colors.white,
                          ),
                        ),
                        SizedBox(width: 8),
                        Text('Publishing...'),
                      ],
                    ),
                    orElse: () => child,
                  ),
                );
              },
              onError: () {
                ScaffoldMessenger.of(context).showSnackBar(
                  SnackBar(content: Text('Failed to publish note')),
                );
              },
            ),
          ],
        ),
      ],
    );
  }
  
  Future<List<String>> _uploadMedia() async {
    // File picking and upload implementation
    final result = await FilePicker.platform.pickFiles(
      type: FileType.media,
      allowMultiple: true,
    );
    
    if (result?.files != null) {
      final uploadedUrls = <String>[];
      for (final file in result!.files) {
        if (file.path != null) {
          // Upload file and get URL
          final url = await BlossomUploader.upload(File(file.path!));
          uploadedUrls.add(url);
        }
      }
      return uploadedUrls;
    }
    
    return [];
  }
  
  Future<void> _publishNote(
    WidgetRef ref, 
    String content, 
    List<String> attachments,
  ) async {
    final signer = ref.read(Signer.activeSignerProvider);
    
    // Append media URLs to content
    final fullContent = [content, ...attachments].join(' ').trim();
    
    final note = PartialNote(fullContent);
    
    // Add imeta tags for attachments
    for (final url in attachments) {
      note.addTag('imeta', ['url $url']);
    }
    
    final signedNote = await note.signWith(signer);
    await ref.storage.save({signedNote});
    await ref.storage.publish({signedNote});
  }
}
```

## Error Handling Patterns

### Detailed Error Information

```dart
class PublishButton extends ConsumerWidget {
  final String content;
  
  const PublishButton({required this.content, super.key});
  
  @override
  Widget build(BuildContext context, WidgetRef ref) {
    return AsyncButtonBuilder(
      child: Text('Publish'),
      onPressed: () async {
        await _publishNote(ref, content);
      },
      builder: (context, child, callback, buttonState) {
        return FilledButton(
          onPressed: buttonState.maybeWhen(
            loading: () => null,
            orElse: () => callback,
          ),
          child: buttonState.maybeWhen(
            loading: () => Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                SizedBox(
                  width: 16,
                  height: 16,
                  child: CircularProgressIndicator(strokeWidth: 2),
                ),
                SizedBox(width: 8),
                Text('Publishing...'),
              ],
            ),
            orElse: () => child,
          ),
        );
      },
      onError: () {
        _showDetailedError(context);
      },
    );
  }
  
  void _showDetailedError(BuildContext context) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: Text('Publication Failed'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('Your note could not be published. This might be due to:'),
            SizedBox(height: 8),
            Text('• Network connection issues'),
            Text('• Relay server unavailable'),
            Text('• Authentication expired'),
            SizedBox(height: 16),
            Text('Your note has been saved locally and will be published when connection is restored.'),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: Text('OK'),
          ),
          FilledButton(
            onPressed: () {
              Navigator.pop(context);
              // Retry logic here
            },
            child: Text('Retry'),
          ),
        ],
      ),
    );
  }
  
  Future<void> _publishNote(WidgetRef ref, String content) async {
    try {
      final signer = ref.read(Signer.activeSignerProvider);
      final note = PartialNote(content);
      final signedNote = await note.signWith(signer);
      
      // Always save locally first
      await ref.storage.save({signedNote});
      
      // Then attempt to publish to relays
      await ref.storage.publish({signedNote});
      
    } catch (e) {
      // Re-throw to trigger onError callback
      rethrow;
    }
  }
}
```

### Retry Logic

```dart
class RetryableAsyncButton extends ConsumerWidget {
  final String text;
  final Future<void> Function() operation;
  final int maxRetries;
  
  const RetryableAsyncButton({
    required this.text,
    required this.operation,
    this.maxRetries = 3,
    super.key,
  });
  
  @override
  Widget build(BuildContext context, WidgetRef ref) {
    return AsyncButtonBuilder(
      child: Text(text),
      onPressed: () async {
        await _executeWithRetry();
      },
      builder: (context, child, callback, buttonState) {
        return FilledButton(
          onPressed: buttonState.maybeWhen(
            loading: () => null,
            orElse: () => callback,
          ),
          child: buttonState.maybeWhen(
            loading: () => Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                SizedBox(
                  width: 16,
                  height: 16,
                  child: CircularProgressIndicator(strokeWidth: 2),
                ),
                SizedBox(width: 8),
                Text('$text...'),
              ],
            ),
            orElse: () => child,
          ),
        );
      },
      onError: () {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('Operation failed after $maxRetries attempts'),
            action: SnackBarAction(
              label: 'Retry',
              onPressed: () {
                // Trigger retry by rebuilding
              },
            ),
          ),
        );
      },
    );
  }
  
  Future<void> _executeWithRetry() async {
    int attempts = 0;
    
    while (attempts < maxRetries) {
      try {
        await operation();
        return; // Success
      } catch (e) {
        attempts++;
        if (attempts >= maxRetries) {
          rethrow; // Final failure
        }
        
        // Wait before retry with exponential backoff
        await Future.delayed(Duration(seconds: attempts * 2));
      }
    }
  }
}
```

## Best Practices

### Performance Considerations

- **Disable buttons during loading** - prevent multiple simultaneous operations
- **Show immediate feedback** - users should see response within 100ms
- **Use appropriate loading indicators** - spinners for buttons, skeletons for content
- **Handle network failures gracefully** - save locally, retry later

### User Experience

- **Clear loading states** - show what's happening ("Signing in...", "Publishing...")
- **Meaningful error messages** - explain what went wrong and how to fix it
- **Retry options** - allow users to retry failed operations
- **Offline capability** - save actions locally when network unavailable

### Code Organization

```dart
// Extract common async patterns into reusable widgets
class NostrAsyncButton extends ConsumerWidget {
  final String text;
  final Future<void> Function(WidgetRef) operation;
  final String? loadingText;
  final String? errorMessage;
  
  const NostrAsyncButton({
    required this.text,
    required this.operation,
    this.loadingText,
    this.errorMessage,
    super.key,
  });
  
  @override
  Widget build(BuildContext context, WidgetRef ref) {
    return AsyncButtonBuilder(
      child: Text(text),
      onPressed: () => operation(ref),
      builder: (context, child, callback, buttonState) {
        return FilledButton(
          onPressed: buttonState.maybeWhen(
            loading: () => null,
            orElse: () => callback,
          ),
          child: buttonState.maybeWhen(
            loading: () => Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                SizedBox(
                  width: 16,
                  height: 16,
                  child: CircularProgressIndicator(strokeWidth: 2),
                ),
                SizedBox(width: 8),
                Text(loadingText ?? '$text...'),
              ],
            ),
            orElse: () => child,
          ),
        );
      },
      onError: () {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text(errorMessage ?? 'Operation failed')),
        );
      },
    );
  }
}
```

### Testing Async Operations

```dart
// For testing, you can mock the async operations
class MockAsyncOperation {
  static Future<void> simulateSuccess({Duration delay = const Duration(seconds: 1)}) async {
    await Future.delayed(delay);
    // Success
  }
  
  static Future<void> simulateFailure({Duration delay = const Duration(seconds: 1)}) async {
    await Future.delayed(delay);
    throw Exception('Simulated failure');
  }
  
  static Future<void> simulateNetworkError() async {
    await Future.delayed(Duration(milliseconds: 500));
    throw SocketException('Network unreachable');
  }
}
```

Remember: Every user action that involves network operations should use async patterns to provide proper feedback and error handling! 