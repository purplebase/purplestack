# Amber Authentication

Complete guide to implementing Nostr authentication using the Amber NIP-55 compatible signer app.

## Overview

Use the `amber_signer` package for secure, user-friendly authentication. Amber handles private key management and signing operations without exposing keys to your app.

## Basic Authentication Setup

### 1. Provider Setup

```dart
import 'package:amber_signer/amber_signer.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

final amberSignerProvider = Provider<AmberSigner>(AmberSigner.new);
```

### 2. Complete Sign-In Screen

```dart
class SignInScreen extends ConsumerWidget {
  const SignInScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final profile =
        ref.watch(Signer.activeProfileProvider(RemoteSource(group: 'social')));
    final pubkey = ref.watch(Signer.activePubkeyProvider);
    
    return Center(
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          if (pubkey == null) ...[
            ElevatedButton(
              onPressed: () => ref.read(amberSignerProvider).signIn(),
              child: const Text('Sign In with Amber'),
            ),
          ] else ...[
            if (profile?.pictureUrl != null)
              CircleAvatar(backgroundImage: NetworkImage(profile!.pictureUrl!)),
            if (profile?.nameOrNpub != null) Text(profile!.nameOrNpub),
            Text(
                '${pubkey.substring(0, 8)}...${pubkey.substring(pubkey.length - 8)}'),
            ElevatedButton(
              onPressed: () => ref.read(amberSignerProvider).signOut(),
              child: const Text('Sign Out'),
            ),
          ],
        ],
      ),
    );
  }
}
```

## Auto Sign-In (Recommended)

Automatically restore the user's session if they've previously authorized your app:

```dart
// In your app initialization, after storage setup
class AppInitializer extends ConsumerWidget {
  @override
  Widget build(BuildContext context, WidgetRef ref) {
    return FutureBuilder(
      future: _initializeApp(ref),
      builder: (context, snapshot) {
        if (snapshot.connectionState == ConnectionState.waiting) {
          return Center(child: CircularProgressIndicator());
        }
        
        return YourMainApp();
      },
    );
  }
  
  Future<void> _initializeApp(WidgetRef ref) async {
    // Initialize storage first
    await ref.read(initializationProvider(StorageConfiguration()).future);
    
    // Then attempt auto sign-in
    await ref.read(amberSignerProvider).attemptAutoSignIn();
  }
}
```

## Advanced Patterns

### Temporary/Utility Signers

For background operations not initiated by the user:

```dart
// For temporary operations or background processing
final utilitySigner = Bip340PrivateKeySigner(
  privateKey, 
  ref, 
  registerSigner: false  // Don't set as active signer
);
```

### Checking Authentication State

```dart
class AuthenticatedWidget extends ConsumerWidget {
  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final pubkey = ref.watch(Signer.activePubkeyProvider);
    final profile = ref.watch(Signer.activeProfileProvider(LocalSource()));
    
    if (pubkey == null) {
      return SignInPrompt();
    }
    
    return switch (profile) {
      AsyncLoading() => ProfileLoadingSkeleton(),
      AsyncError() => ProfileErrorWidget(),
      AsyncData(:final value) => AuthenticatedContent(profile: value),
    };
  }
}
```

### Error Handling

```dart
class SignInButton extends ConsumerWidget {
  @override
  Widget build(BuildContext context, WidgetRef ref) {
    return AsyncButtonBuilder(
      child: Text('Sign In with Amber'),
      onPressed: () async {
        try {
          await ref.read(amberSignerProvider).signIn();
        } catch (e) {
          if (context.mounted) {
            ScaffoldMessenger.of(context).showSnackBar(
              SnackBar(
                content: Text('Sign-in failed: Please install Amber app'),
                action: SnackBarAction(
                  label: 'Install',
                  onPressed: () => launchUrl(Uri.parse('https://github.com/greenart7c3/Amber')),
                ),
              ),
            );
          }
        }
      },
      builder: (context, child, callback, buttonState) {
        return FilledButton(
          onPressed: buttonState.maybeWhen(
            loading: () => null,
            orElse: () => callback,
          ),
          child: buttonState.maybeWhen(
            loading: () => SizedBox(
              width: 20,
              height: 20,
              child: CircularProgressIndicator(strokeWidth: 2),
            ),
            orElse: () => child,
          ),
        );
      },
    );
  }
}
```

## Integration Tips

- **Always prefer Amber authentication** over manual private key entry
- **Use auto sign-in** for better user experience
- **Handle Amber app not installed** gracefully with helpful error messages
- **Use AsyncButtonBuilder** for sign-in operations to show loading states
- **Check authentication state** before performing any signed operations

## Fallback to nsec (Optional)

Only implement nsec fallback if specifically requested by the user:

```dart
class SignInOptions extends ConsumerWidget {
  @override
  Widget build(BuildContext context, WidgetRef ref) {
    return Column(
      children: [
        // Primary option - Amber
        FilledButton(
          onPressed: () => ref.read(amberSignerProvider).signIn(),
          child: Text('Sign In with Amber'),
        ),
        
        SizedBox(height: 16),
        
        // Fallback option - nsec
        OutlinedButton(
          onPressed: () => _showNsecDialog(context, ref),
          child: Text('Sign In with Private Key'),
        ),
      ],
    );
  }
  
  void _showNsecDialog(BuildContext context, WidgetRef ref) {
    // Implementation for nsec input dialog
    // Only show this if user specifically requests it
  }
}
``` 