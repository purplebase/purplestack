# File Uploads with Blossom

Complete implementation guide for uploading files to Nostr using the Blossom protocol with hash-based deduplication and authorization.

## Overview

Blossom is a protocol for storing files on Nostr using content-addressed storage. Files are identified by their SHA-256 hash, enabling automatic deduplication.

## Dependencies

Add these imports to your upload implementation:

```dart
import 'dart:io';
import 'package:crypto/crypto.dart';
import 'package:http/http.dart' as http;
import 'package:mime/mime.dart';
import 'package:path/path.dart' as path;
import 'package:models/models.dart';
```

## Complete Upload Flow

### 1. File Upload with Progress

```dart
class BlossomUploader {
  final String serverUrl;
  final Signer signer;
  
  BlossomUploader({required this.serverUrl, required this.signer});
  
  Future<String> uploadFile(
    File file, {
    Function(double)? onProgress,
  }) async {
    // 1. Calculate file hash and prepare authorization
    final bytes = await file.readAsBytes();
    final assetHash = sha256.convert(bytes).toString();
    final mimeType = lookupMimeType(file.path);
    
    // 2. Create Blossom authorization event
    final partialAuthorization = PartialBlossomAuthorization()
      ..content = 'Upload asset ${path.basename(file.path)}'
      ..type = BlossomAuthorizationType.upload
      ..mimeType = mimeType
      ..expiration = DateTime.now().add(Duration(hours: 1))
      ..hash = assetHash;

    final authorization = await partialAuthorization.signWith(signer);
    
    // 3. Check if file already exists on server
    final assetUploadUrl = '$serverUrl/$assetHash';
    final headResponse = await http.head(Uri.parse(assetUploadUrl));

    if (headResponse.statusCode == 200) {
      // File already exists, use existing URL
      onProgress?.call(1.0);
      return assetUploadUrl;
    }
    
    // 4. Upload file to Blossom server
    final response = await http.put(
      Uri.parse('$serverUrl/upload'),
      body: bytes,
      headers: {
        if (mimeType != null) 'Content-Type': mimeType,
        'Authorization': 'Nostr ${authorization.toBase64()}',
      },
    );

    if (response.statusCode == 200) {
      onProgress?.call(1.0);
      return assetUploadUrl;
    } else {
      throw BlossomUploadException(
        'Upload failed: ${response.statusCode} ${response.body}',
      );
    }
  }
}

class BlossomUploadException implements Exception {
  final String message;
  BlossomUploadException(this.message);
  
  @override
  String toString() => 'BlossomUploadException: $message';
}
```

### 2. Upload with Progress UI

```dart
class FileUploadWidget extends HookConsumerWidget {
  final File file;
  
  const FileUploadWidget({required this.file, super.key});
  
  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final uploadProgress = useState<double>(0.0);
    final uploadStatus = useState<String>('Ready to upload');
    final isUploading = useState<bool>(false);
    final uploadedUrl = useState<String?>(null);
    
    Future<void> handleUpload() async {
      if (isUploading.value) return;
      
      isUploading.value = true;
      uploadStatus.value = 'Uploading...';
      
      try {
        final signer = ref.read(Signer.activeSignerProvider);
        final uploader = BlossomUploader(
          serverUrl: 'https://your-blossom-server.com',
          signer: signer,
        );
        
        final url = await uploader.uploadFile(
          file,
          onProgress: (progress) {
            uploadProgress.value = progress;
            uploadStatus.value = 'Uploading... ${(progress * 100).toInt()}%';
          },
        );
        
        uploadedUrl.value = url;
        uploadStatus.value = 'Upload complete!';
        
      } catch (e) {
        uploadStatus.value = 'Upload failed: $e';
      } finally {
        isUploading.value = false;
      }
    }
    
    return Card(
      child: Padding(
        padding: EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('File: ${path.basename(file.path)}'),
            SizedBox(height: 8),
            
            if (isUploading.value) ...[
              LinearPercentIndicator(
                percent: uploadProgress.value,
                backgroundColor: Colors.grey[300],
                progressColor: Theme.of(context).colorScheme.primary,
                lineHeight: 6.0,
                trailing: Text('${(uploadProgress.value * 100).toInt()}%'),
              ),
              SizedBox(height: 8),
            ],
            
            Text(uploadStatus.value),
            SizedBox(height: 12),
            
            Row(
              children: [
                if (!isUploading.value && uploadedUrl.value == null)
                  FilledButton(
                    onPressed: handleUpload,
                    child: Text('Upload'),
                  ),
                
                if (uploadedUrl.value != null) ...[
                  OutlinedButton(
                    onPressed: () => _attachToNote(context, ref, uploadedUrl.value!),
                    child: Text('Attach to Note'),
                  ),
                  SizedBox(width: 8),
                  IconButton(
                    onPressed: () => Clipboard.setData(ClipboardData(text: uploadedUrl.value!)),
                    icon: Icon(Icons.copy),
                    tooltip: 'Copy URL',
                  ),
                ],
              ],
            ),
          ],
        ),
      ),
    );
  }
  
  void _attachToNote(BuildContext context, WidgetRef ref, String url) {
    // Navigate to note composer with pre-filled URL
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) => NoteComposerScreen(prefilledContent: url),
      ),
    );
  }
}
```

## File Deletion

```dart
extension BlossomDeleter on BlossomUploader {
  Future<bool> deleteFile(String assetHash) async {
    // Create deletion authorization
    final deleteAuth = PartialBlossomAuthorization()
      ..content = 'Delete asset $assetHash'
      ..type = BlossomAuthorizationType.delete
      ..expiration = DateTime.now().add(Duration(hours: 1))
      ..hash = assetHash;

    final signedDeleteAuth = await deleteAuth.signWith(signer);

    // Delete from server
    final deleteResponse = await http.delete(
      Uri.parse('$serverUrl/$assetHash'),
      headers: {
        'Authorization': 'Nostr ${signedDeleteAuth.toBase64()}',
      },
    );
    
    return deleteResponse.statusCode == 200;
  }
}
```

## Attaching Files to Notes

### For Kind 1 Events (Notes)

```dart
class NoteWithMedia {
  static PartialNote createWithMedia({
    required String text,
    required List<UploadedFile> files,
  }) {
    // Append URLs to content
    final contentParts = [text];
    for (final file in files) {
      contentParts.add(file.url);
    }
    final fullContent = contentParts.join(' ').trim();
    
    // Create note with imeta tags
    final note = PartialNote(fullContent);
    
    for (final file in files) {
      note.addTag('imeta', [
        'url ${file.url}',
        if (file.mimeType != null) 'm ${file.mimeType}',
        'x ${file.hash}',
        if (file.size != null) 'size ${file.size}',
        if (file.dimensions != null) 'dim ${file.dimensions}',
      ]);
    }
    
    return note;
  }
}

class UploadedFile {
  final String url;
  final String hash;
  final String? mimeType;
  final int? size;
  final String? dimensions; // "1920x1080"
  
  UploadedFile({
    required this.url,
    required this.hash,
    this.mimeType,
    this.size,
    this.dimensions,
  });
}
```

### Complete Note Composer with Media

```dart
class MediaNoteComposer extends HookConsumerWidget {
  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final textController = useTextEditingController();
    final uploadedFiles = useState<List<UploadedFile>>([]);
    final isPublishing = useState<bool>(false);
    
    Future<void> pickAndUploadFile() async {
      final result = await FilePicker.platform.pickFiles(
        type: FileType.media,
        allowMultiple: true,
      );
      
      if (result?.files != null) {
        for (final platformFile in result!.files) {
          if (platformFile.path != null) {
            final file = File(platformFile.path!);
            await _uploadFile(file, uploadedFiles);
          }
        }
      }
    }
    
    Future<void> publishNote() async {
      if (isPublishing.value) return;
      
      isPublishing.value = true;
      try {
        final signer = ref.read(Signer.activeSignerProvider);
        
        final note = NoteWithMedia.createWithMedia(
          text: textController.text,
          files: uploadedFiles.value,
        );
        
        final signedNote = await note.signWith(signer);
        
        // Save locally and publish to relays
        await ref.storage.save({signedNote});
        await ref.storage.publish({signedNote});
        
        Navigator.pop(context);
        
      } catch (e) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Failed to publish: $e')),
        );
      } finally {
        isPublishing.value = false;
      }
    }
    
    return Scaffold(
      appBar: AppBar(
        title: Text('New Note'),
        actions: [
          TextButton(
            onPressed: isPublishing.value ? null : publishNote,
            child: isPublishing.value 
                ? SizedBox(
                    width: 20,
                    height: 20,
                    child: CircularProgressIndicator(strokeWidth: 2),
                  )
                : Text('Publish'),
          ),
        ],
      ),
      body: Column(
        children: [
          Expanded(
            child: Padding(
              padding: EdgeInsets.all(16),
              child: TextField(
                controller: textController,
                decoration: InputDecoration(
                  hintText: 'What\'s happening?',
                  border: InputBorder.none,
                ),
                maxLines: null,
                expands: true,
                textAlignVertical: TextAlignVertical.top,
              ),
            ),
          ),
          
          // Media preview
          if (uploadedFiles.value.isNotEmpty)
            Container(
              height: 120,
              child: ListView.builder(
                scrollDirection: Axis.horizontal,
                itemCount: uploadedFiles.value.length,
                itemBuilder: (context, index) {
                  final file = uploadedFiles.value[index];
                  return MediaPreviewCard(
                    file: file,
                    onRemove: () {
                      final files = List<UploadedFile>.from(uploadedFiles.value);
                      files.removeAt(index);
                      uploadedFiles.value = files;
                    },
                  );
                },
              ),
            ),
          
          // Bottom toolbar
          Container(
            padding: EdgeInsets.all(16),
            child: Row(
              children: [
                IconButton(
                  onPressed: pickAndUploadFile,
                  icon: Icon(Icons.attach_file),
                  tooltip: 'Attach Media',
                ),
                Spacer(),
                Text('${textController.text.length}/280'),
              ],
            ),
          ),
        ],
      ),
    );
  }
  
  Future<void> _uploadFile(
    File file, 
    ValueNotifier<List<UploadedFile>> uploadedFiles,
  ) async {
    // Implementation for uploading and adding to uploadedFiles list
    // Show progress in UI, handle errors, etc.
  }
}
```

## Configuration and Best Practices

### Server Configuration

```dart
class BlossomConfig {
  static const String defaultServer = 'https://blossom.primal.net';
  static const Duration authExpiration = Duration(hours: 1);
  static const int maxFileSize = 50 * 1024 * 1024; // 50MB
  
  static const Set<String> supportedMimeTypes = {
    'image/jpeg',
    'image/png', 
    'image/gif',
    'image/webp',
    'video/mp4',
    'video/webm',
    'audio/mpeg',
    'audio/wav',
  };
}
```

### Error Handling

- **File too large**: Check file size before upload
- **Unsupported format**: Validate MIME type
- **Network errors**: Implement retry logic
- **Authorization failed**: Refresh signer and retry
- **Server unavailable**: Fall back to alternative servers

### Security Considerations

- **Authorization expiration**: Keep auth events short-lived (1 hour max)
- **Hash verification**: Always verify uploaded file hash matches
- **MIME type validation**: Don't trust client-provided MIME types
- **Server allowlist**: Only upload to trusted Blossom servers 