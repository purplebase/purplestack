# Custom Nostr Models

Complete guide to creating custom Nostr event models when existing models don't meet your needs.

## ⚠️ Important: Research First

**BEFORE creating custom models:**

1. Check existing models in `tools/reference/`
2. Search all NIPs using the Nostr MCP server
3. Investigate thoroughly with relevant NIPs
4. Only create custom kinds after proving no existing solution works

**Custom kinds sacrifice interoperability** - use as last resort only.

## Understanding Model Types

Different kind ranges have different storage behaviors:

- **Regular Events** (1000-9999): Stored permanently, like notes and reactions
- **Replaceable Events** (10000-19999): Only latest per pubkey+kind stored
- **Addressable Events** (30000-39999): Latest per pubkey+kind+d-tag stored  
- **Ephemeral Events** (20000-29999): Not stored permanently

## Complete Custom Model Example

Let's create a classified listing marketplace:

### 1. Model Definition

```dart
// Regular model for classified listings
class ClassifiedListing extends RegularModel<ClassifiedListing> {
  ClassifiedListing.fromMap(super.map, super.ref) : super.fromMap();
  
  // Property getters using tags
  String? get title => event.getFirstTagValue('title');
  String? get price => event.getFirstTagValue('price');
  String? get category => event.getFirstTagValue('t'); // Using 't' tag for relay indexing
  String? get location => event.getFirstTagValue('location');
  String? get condition => event.getFirstTagValue('condition');
  List<String> get imageUrls => event.getTagValues('image');
  
  // Content is the description
  String get description => event.content;
  
  // Parse published date from tag
  DateTime? get publishedAt => 
      event.getFirstTagValue('published_at')?.toInt()?.toDate();
      
  // Derived properties
  bool get hasImages => imageUrls.isNotEmpty;
  bool get hasPrice => price != null && price!.isNotEmpty;
  
  // Helper for price display
  String get formattedPrice {
    if (price == null || price!.isEmpty) return 'Price not specified';
    return '\$${price}';
  }
}

// Partial model for creating new listings
class PartialClassifiedListing extends RegularPartialModel<ClassifiedListing> 
    with PartialClassifiedListingMixin {
  
  PartialClassifiedListing({
    required String title,
    required String description,
    required String category,
    String? price,
    String? location,
    String? condition,
    List<String>? imageUrls,
    DateTime? publishedAt,
  }) {
    event.content = description;
    event.addTagValue('title', title);
    event.addTagValue('t', category); // Use 't' for relay filtering
    
    if (price != null) event.addTagValue('price', price);
    if (location != null) event.addTagValue('location', location);
    if (condition != null) event.addTagValue('condition', condition);
    
    if (imageUrls != null) {
      for (final url in imageUrls) {
        event.addTagValue('image', url);
      }
    }
    
    if (publishedAt != null) {
      event.addTagValue('published_at', publishedAt.toSeconds().toString());
    }
    
    // Add alt tag for NIP-31 compatibility
    event.addTagValue('alt', 'Classified listing: $title');
  }
}

// Mixin for partial model (if needed for additional methods)
mixin PartialClassifiedListingMixin on RegularPartialModel<ClassifiedListing> {
  void addImage(String imageUrl) {
    event.addTagValue('image', imageUrl);
  }
  
  void removeImage(String imageUrl) {
    event.tags.removeWhere((tag) => 
        tag.length >= 2 && tag[0] == 'image' && tag[1] == imageUrl);
  }
  
  void updatePrice(String newPrice) {
    event.removeTag('price');
    event.addTagValue('price', newPrice);
  }
}
```

### 2. Model Registration

```dart
// Create custom initialization provider
final customInitializationProvider = FutureProvider((ref) async {
  // Initialize base storage first
  await ref.read(initializationProvider(StorageConfiguration()).future);
  
  // Register custom models with chosen kind number (check NIPs first!)
  Model.register(
    kind: 30402, // Using addressable event range for marketplace items
    constructor: ClassifiedListing.fromMap, 
    partialConstructor: PartialClassifiedListing.fromMap,
  );
  
  return true;
});

// Use in your main app
class MyApp extends ConsumerWidget {
  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final initState = ref.watch(customInitializationProvider);
    
    return switch (initState) {
      AsyncLoading() => MaterialApp(
        home: Scaffold(
          body: Center(child: CircularProgressIndicator()),
        ),
      ),
      AsyncError(:final error) => MaterialApp(
        home: Scaffold(
          body: Center(child: Text('Initialization Error: $error')),
        ),
      ),
      AsyncData() => MaterialApp(
        title: 'Marketplace App',
        home: MarketplaceScreen(),
      ),
    };
  }
}
```

### 3. Using Custom Models

#### Creating and Publishing

```dart
class CreateListingScreen extends HookConsumerWidget {
  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final titleController = useTextEditingController();
    final descriptionController = useTextEditingController();
    final priceController = useTextEditingController();
    final selectedCategory = useState<String>('electronics');
    
    Future<void> publishListing() async {
      final signer = ref.read(Signer.activeSignerProvider);
      
      // Create the listing
      final listing = PartialClassifiedListing(
        title: titleController.text,
        description: descriptionController.text,
        category: selectedCategory.value,
        price: priceController.text.isEmpty ? null : priceController.text,
        location: 'San Francisco, CA', // Could be from user input
        condition: 'excellent',
        publishedAt: DateTime.now(),
      );
      
      // Sign the event
      final signedListing = await listing.signWith(signer);
      
      // Save locally and publish to relays
      await ref.storage.save({signedListing});
      await ref.storage.publish({signedListing});
      
      Navigator.pop(context);
    }
    
    return Scaffold(
      appBar: AppBar(title: Text('Create Listing')),
      body: Padding(
        padding: EdgeInsets.all(16),
        child: Column(
          children: [
            TextField(
              controller: titleController,
              decoration: InputDecoration(labelText: 'Title'),
            ),
            SizedBox(height: 16),
            TextField(
              controller: descriptionController,
              decoration: InputDecoration(labelText: 'Description'),
              maxLines: 3,
            ),
            SizedBox(height: 16),
            TextField(
              controller: priceController,
              decoration: InputDecoration(labelText: 'Price (optional)'),
              keyboardType: TextInputType.number,
            ),
            SizedBox(height: 16),
            DropdownButtonFormField<String>(
              value: selectedCategory.value,
              decoration: InputDecoration(labelText: 'Category'),
              items: [
                DropdownMenuItem(value: 'electronics', child: Text('Electronics')),
                DropdownMenuItem(value: 'vehicles', child: Text('Vehicles')),
                DropdownMenuItem(value: 'furniture', child: Text('Furniture')),
              ],
              onChanged: (value) => selectedCategory.value = value!,
            ),
            Spacer(),
            FilledButton(
              onPressed: publishListing,
              child: Text('Publish Listing'),
            ),
          ],
        ),
      ),
    );
  }
}
```

#### Querying Custom Models

```dart
class MarketplaceScreen extends ConsumerWidget {
  @override
  Widget build(BuildContext context, WidgetRef ref) {
    // Query all listings with relationships
    final listingsState = ref.watch(
      query<ClassifiedListing>(
        limit: 50,
        tags: {'#t': {'electronics'}}, // Filter by category
        and: (listing) => {
          listing.author, // Include author profile
        },
      ),
    );
    
    return Scaffold(
      appBar: AppBar(
        title: Text('Marketplace'),
        actions: [
          IconButton(
            onPressed: () => Navigator.push(
              context,
              MaterialPageRoute(builder: (context) => CreateListingScreen()),
            ),
            icon: Icon(Icons.add),
          ),
        ],
      ),
      body: switch (listingsState) {
        StorageLoading() => Center(child: CircularProgressIndicator()),
        StorageError(:final error) => Center(child: Text('Error: $error')),
        StorageData(:final models) => ListView.builder(
          itemCount: models.length,
          itemBuilder: (context, index) {
            final listing = models[index];
            return ListingCard(listing: listing);
          },
        ),
      },
    );
  }
}

class ListingCard extends StatelessWidget {
  final ClassifiedListing listing;
  
  const ListingCard({required this.listing, super.key});
  
  @override
  Widget build(BuildContext context) {
    return Card(
      margin: EdgeInsets.symmetric(horizontal: 16, vertical: 8),
      child: Padding(
        padding: EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Expanded(
                  child: Text(
                    listing.title ?? 'Untitled',
                    style: Theme.of(context).textTheme.titleMedium,
                  ),
                ),
                if (listing.hasPrice)
                  Chip(
                    label: Text(listing.formattedPrice),
                    backgroundColor: Theme.of(context).colorScheme.primaryContainer,
                  ),
              ],
            ),
            
            SizedBox(height: 8),
            
            Text(
              listing.description,
              style: Theme.of(context).textTheme.bodyMedium,
              maxLines: 3,
              overflow: TextOverflow.ellipsis,
            ),
            
            SizedBox(height: 12),
            
            Row(
              children: [
                ProfileAvatar(
                  profile: listing.author.value,
                  radius: 16,
                ),
                SizedBox(width: 8),
                Expanded(
                  child: Text(
                    listing.author.value?.displayName ?? 'Anonymous',
                    style: Theme.of(context).textTheme.bodySmall,
                  ),
                ),
                Text(
                  TimeUtils.formatTimestamp(listing.createdAt),
                  style: Theme.of(context).textTheme.bodySmall,
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}
```

## Different Model Types Examples

### Replaceable Event (Profile Extension)

```dart
// Example: User preferences (kind 10xxx)
class UserPreferences extends ReplaceableModel<UserPreferences> {
  UserPreferences.fromMap(super.map, super.ref) : super.fromMap();
  
  String? get theme => event.getFirstTagValue('theme');
  String? get language => event.getFirstTagValue('language');
  bool get notificationsEnabled => 
      event.getFirstTagValue('notifications') == 'true';
}

class PartialUserPreferences extends ReplaceablePartialModel<UserPreferences> {
  PartialUserPreferences({
    String theme = 'system',
    String language = 'en',
    bool notificationsEnabled = true,
  }) {
    event.content = '';
    event.addTagValue('theme', theme);
    event.addTagValue('language', language);
    event.addTagValue('notifications', notificationsEnabled.toString());
  }
}
```

### Addressable Event (Blog Posts)

```dart
// Example: Blog posts (kind 30xxx)
class BlogPost extends ParameterizableReplaceableModel<BlogPost> {
  BlogPost.fromMap(super.map, super.ref) : super.fromMap();
  
  String get identifier => event.identifier; // d-tag value
  String? get title => event.getFirstTagValue('title');
  String? get summary => event.getFirstTagValue('summary');
  String get content => event.content; // Markdown content
  List<String> get tags => event.getTagValues('t');
  
  DateTime? get publishedAt => 
      event.getFirstTagValue('published_at')?.toInt()?.toDate();
}

class PartialBlogPost extends ParameterizableReplaceablePartialModel<BlogPost> {
  PartialBlogPost({
    required String identifier,
    required String title,
    required String content,
    String? summary,
    List<String>? tags,
  }) {
    event.identifier = identifier; // Sets d-tag
    event.content = content;
    event.addTagValue('title', title);
    
    if (summary != null) event.addTagValue('summary', summary);
    if (tags != null) {
      for (final tag in tags) {
        event.addTagValue('t', tag);
      }
    }
    
    event.addTagValue('published_at', DateTime.now().toSeconds().toString());
  }
}
```

### Ephemeral Event (Live Status)

```dart
// Example: Live typing indicator (kind 20xxx)
class TypingIndicator extends EphemeralModel<TypingIndicator> {
  TypingIndicator.fromMap(super.map, super.ref) : super.fromMap();
  
  String? get channelId => event.getFirstTagValue('channel');
  bool get isTyping => event.content == 'typing';
}

class PartialTypingIndicator extends EphemeralPartialModel<TypingIndicator> {
  PartialTypingIndicator({
    required String channelId,
    required bool isTyping,
  }) {
    event.content = isTyping ? 'typing' : 'stopped';
    event.addTagValue('channel', channelId);
  }
}
```

## Best Practices

### Tag Design

- **Use 't' tags for categories** - relay-indexed for efficient filtering
- **Single-letter tags for queryable data** - multi-letter tags aren't indexed
- **Content for large text** - descriptions, markdown, JSON
- **Tags for metadata** - titles, prices, categories, dates

### Kind Selection

- **Research thoroughly first** - check existing NIPs and models
- **Document in NIP.md** - create project NIP documentation
- **Consider interoperability** - will other clients understand this?
- **Choose appropriate range** - regular vs replaceable vs addressable

### Performance

- **Use relationships efficiently** - load related data with `and` operator
- **Filter at relay level** - use tag filters, not client-side filtering
- **Combine queries when possible** - multiple kinds in single query
- **Cache frequently accessed data** - leverage local storage

### Error Handling

```dart
try {
  final listing = PartialClassifiedListing(/* ... */);
  final signed = await listing.signWith(signer);
  await ref.storage.save({signed});
  await ref.storage.publish({signed});
} catch (e) {
  // Handle signing, storage, or network errors
  ScaffoldMessenger.of(context).showSnackBar(
    SnackBar(content: Text('Failed to publish listing: $e')),
  );
}
```

Remember: Custom models are powerful but break interoperability. Use existing models whenever possible! 